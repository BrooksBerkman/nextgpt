# NExT-GPT Experiment 5 - Experiment Report
# 上传至 GitHub 时请将此文件重命名为 README.md
# 并将上面的英文 README.md 重命名为 README_en.md 或删除
