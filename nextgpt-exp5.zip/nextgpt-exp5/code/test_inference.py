#!/usr/bin/env python3
"""
NExT-GPT 轻量级推理测试脚本
测试核心 LLM 推理流程，不加载 Diffusion 模型
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from model.anyToImageVideoAudio import NextGPTModel
import torch
from config import load_config

print("=" * 60)
print("NExT-GPT 核心推理测试 (无 Diffusion 模型)")
print("=" * 60)

# 初始化模型
g_cuda = torch.Generator(device='cuda').manual_seed(1337)
args = {
    'model': 'nextgpt',
    'nextgpt_ckpt_path': '../ckpt/delta_ckpt/nextgpt/7b_tiva_v0',
    'max_length': 128,
    'stage': 3,
    'root_dir': '../',
    'mode': 'validate',
}
args.update(load_config(args))

print("\n[1/3] 初始化 NextGPTModel...")
model = NextGPTModel(**args)

print("\n[2/3] 加载 NExT-GPT delta checkpoint...")
delta_ckpt = torch.load(
    os.path.join(args['nextgpt_ckpt_path'], 'pytorch_model.pt'),
    map_location=torch.device('cuda')
)
model.load_state_dict(delta_ckpt, strict=False)
model = model.eval().half().cuda()
print("[OK] 模型加载完成!")
print(f"    可训练参数: {sum(p.numel() for p in model.parameters()):,}")

print("\n[3/3] 执行推理测试...")

# 测试1：纯文本输入（图像生成）
print("\n--- 测试1: 纯文本 -> 文本+图像信号 ---")
prompt1 = "### Human: Show me a beautiful sunset over the ocean. ### Assistant:"
print(f"Prompt: {prompt1}")

response1 = model.generate({
    'prompt': prompt1,
    'image_paths': [],
    'audio_paths': [],
    'video_paths': [],
    'thermal_paths': [],
    'top_p': 1.0,
    'temperature': 0.1,
    'max_tgt_len': 200,
    'modality_embeds': None,
    'filter_value': -float('Inf'),
    'min_word_tokens': 10,
    'gen_scale_factor': 4.0,
    'max_num_imgs': 1,
    'stops_id': [[835]],
    'load_sd': False,  # 关闭 Diffusion 模型
    'generator': g_cuda,
    'guidance_scale_for_img': 7.5,
    'num_inference_steps_for_img': 50,
    'guidance_scale_for_vid': 7.5,
    'num_inference_steps_for_vid': 50,
    'max_num_vids': 1,
    'height': 320,
    'width': 576,
    'num_frames': 24,
    'guidance_scale_for_aud': 7.5,
    'num_inference_steps_for_aud': 50,
    'max_num_auds': 1,
    'audio_length_in_s': 9,
    'ENCOUNTERS': 1,
})

for item in response1:
    if isinstance(item, str):
        print(f"文本响应: {item}")
    else:
        for key, value in item.items():
            print(f"输出模态: {key}")
            print(f"内容类型: {type(value)}")

# 测试2：文本+图像理解
print("\n--- 测试2: 文本对话 ---")
prompt2 = "### Human: What is the capital of France? ### Assistant:"
print(f"Prompt: {prompt2}")

response2 = model.generate({
    'prompt': prompt2,
    'image_paths': [],
    'audio_paths': [],
    'video_paths': [],
    'thermal_paths': [],
    'top_p': 1.0,
    'temperature': 0.1,
    'max_tgt_len': 100,
    'modality_embeds': None,
    'filter_value': -float('Inf'),
    'min_word_tokens': 5,
    'gen_scale_factor': 4.0,
    'max_num_imgs': 1,
    'stops_id': [[835]],
    'load_sd': False,
    'generator': g_cuda,
    'guidance_scale_for_img': 7.5,
    'num_inference_steps_for_img': 50,
    'guidance_scale_for_vid': 7.5,
    'num_inference_steps_for_vid': 50,
    'max_num_vids': 1,
    'height': 320,
    'width': 576,
    'num_frames': 24,
    'guidance_scale_for_aud': 7.5,
    'num_inference_steps_for_aud': 50,
    'max_num_auds': 1,
    'audio_length_in_s': 9,
    'ENCOUNTERS': 1,
})

for item in response2:
    if isinstance(item, str):
        print(f"文本响应: {item}")
    else:
        for key, value in item.items():
            print(f"输出模态: {key}")

print("\n" + "=" * 60)
print("测试完成!")
print("=" * 60)
