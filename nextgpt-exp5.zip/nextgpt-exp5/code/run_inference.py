#!/usr/bin/env python3
"""
NExT-GPT 图像生成推理测试脚本
用法: python run_inference.py
依赖: conda activate nextgpt
"""
import os
import sys

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.chdir(os.path.dirname(os.path.abspath(__file__)))

from model.anyToImageVideoAudio import NextGPTModel
from config import load_config
import torch

print("=" * 60)
print("NExT-GPT 图像生成推理测试")
print("=" * 60)

# 初始化模型
g_cuda = torch.Generator(device='cuda').manual_seed(1337)
args = {
    'model': 'nextgpt',
    'nextgpt_ckpt_path': '../ckpt/delta_ckpt/nextgpt/7b_tiva_v0',
    'max_length': 128,
    'stage': 3,
    'root_dir': '../',
    'mode': 'validate',
}
args.update(load_config(args))

print("\n[1/2] 初始化并加载模型...")
model = NextGPTModel(**args)
delta_ckpt = torch.load(
    os.path.join(args['nextgpt_ckpt_path'], 'pytorch_model.pt'),
    map_location='cuda'
)
model.load_state_dict(delta_ckpt, strict=False)
model = model.eval().half().cuda()
print("[OK] 模型加载完成!")

# 创建输出目录
os.makedirs('./assets/images', exist_ok=True)

# 执行推理
print("\n[2/2] 执行推理...")
prompt = "draw a cat on the grass"
print(f"Prompt: {prompt}")

response = model.generate({
    'prompt': prompt,
    'image_paths': [],
    'audio_paths': [],
    'video_paths': [],
    'thermal_paths': [],
    'top_p': 1.0,
    'temperature': 0.4,
    'max_tgt_len': 100,
    'modality_embeds': None,
    'filter_value': -float('Inf'),
    'min_word_tokens': 5,
    'gen_scale_factor': 4.0,
    'max_num_imgs': 1,
    'stops_id': [[835]],
    'load_sd': True,
    'generator': g_cuda,
    'guidance_scale_for_img': 7.5,
    'num_inference_steps_for_img': 20,
    'guidance_scale_for_vid': 7.5,
    'num_inference_steps_for_vid': 20,
    'max_num_vids': 1,
    'height': 256,
    'width': 384,
    'num_frames': 16,
    'guidance_scale_for_aud': 7.5,
    'num_inference_steps_for_aud': 20,
    'max_num_auds': 1,
    'audio_length_in_s': 5,
    'ENCOUNTERS': 1,
})

print("\n--- 推理结果 ---")
for item in response:
    if isinstance(item, str):
        print(f"文本响应: {item}")
    elif 'img' in item:
        for i, m in enumerate(item['img']):
            if not isinstance(m, str):
                fname = './assets/images/cat_on_grass.jpg'
                m[0].save(fname)
                print(f"图像已保存: {fname}")
    elif 'text' in item:
        print(f"文本响应: {item['text']}")
    else:
        for key, value in item.items():
            print(f"[{key}]: {type(value)}")

print("\n" + "=" * 60)
print("推理完成!")
print("=" * 60)
