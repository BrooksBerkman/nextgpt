#!/bin/bash
# ============================================================
# NExT-GPT Checkpoint 下载脚本
# 功能：下载所有必需的模型权重
# 使用：bash download_checkpoints.sh
# ============================================================

set -e

# 设置 HuggingFace 镜像
export HF_ENDPOINT=https://hf-mirror.com

# 项目根目录（假设脚本在 nextgpt-exp5/ 目录下运行）
PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
CKPT_DIR="$PROJECT_ROOT/ckpt"

echo "============================================"
echo "NExT-GPT Checkpoint 下载脚本"
echo "============================================"
echo "项目根目录: $PROJECT_ROOT"
echo "Checkpoint 目录: $CKPT_DIR"
echo ""

# 创建目录结构
echo "[0/4] 创建目录结构..."
mkdir -p "$CKPT_DIR/pretrained_ckpt/imagebind_ckpt/huge"
mkdir -p "$CKPT_DIR/pretrained_ckpt/vicuna_ckpt/7b_v0"
mkdir -p "$CKPT_DIR/delta_ckpt/nextgpt/7b_tiva_v0"
echo "目录创建完成"
echo ""

# 1. 下载 ImageBind
echo "[1/4] 下载 ImageBind (4.5 GB)..."
if [ -f "$CKPT_DIR/pretrained_ckpt/imagebind_ckpt/huge/imagebind_huge.pth" ]; then
    echo "ImageBind 已存在，跳过下载"
else
    wget -O "$CKPT_DIR/pretrained_ckpt/imagebind_ckpt/huge/imagebind_huge.pth" \
        https://dl.fbaipublicfiles.com/imagebind/imagebind_huge.pth
fi
echo ""

# 2. 下载 Vicuna-7B-v0
echo "[2/4] 下载 Vicuna-7B-v0 (约 13.5 GB)..."
echo "说明: 官方 lmsys/vicuna-7b-v0 需要授权"
echo "      使用 BetterHF/vicuna-7b 社区版作为替代方案"
if [ -f "$CKPT_DIR/pretrained_ckpt/vicuna_ckpt/7b_v0/pytorch_model-00001-of-00002.bin" ]; then
    echo "Vicuna-7B-v0 已存在，跳过下载"
else
    huggingface-cli download BetterHF/vicuna-7b \
        --local-dir "$CKPT_DIR/pretrained_ckpt/vicuna_ckpt/7b_v0" \
        --local-dir-use-symlinks False
fi
echo ""

# 3. 下载 NExT-GPT delta checkpoint
echo "[3/4] 下载 NExT-GPT delta checkpoint (792 MB)..."
if [ -f "$CKPT_DIR/delta_ckpt/nextgpt/7b_tiva_v0/pytorch_model.pt" ]; then
    echo "NExT-GPT delta checkpoint 已存在，跳过下载"
else
    huggingface-cli download ChocoWu/nextgpt_7b_tiva_v0 \
        --local-dir "$CKPT_DIR/delta_ckpt/nextgpt/7b_tiva_v0" \
        --local-dir-use-symlinks False
fi
echo ""

# 4. 下载 Stable Diffusion
echo "[4/4] 下载 Stable Diffusion (约 5-7 GB，推理时自动下载)..."
echo "SD 会在首次推理时自动下载，无需手动下载"
echo ""

# 验证下载结果
echo "============================================"
echo "Checkpoint 下载验证"
echo "============================================"
echo ""

echo "ImageBind:"
ls -lh "$CKPT_DIR/pretrained_ckpt/imagebind_ckpt/huge/imagebind_huge.pth" 2>/dev/null || echo "  缺失!"

echo ""
echo "Vicuna-7B-v0:"
ls -lh "$CKPT_DIR/pretrained_ckpt/vicuna_ckpt/7b_v0/"*.bin 2>/dev/null | head -3 || echo "  缺失!"

echo ""
echo "NExT-GPT delta:"
ls -lh "$CKPT_DIR/delta_ckpt/nextgpt/7b_tiva_v0/pytorch_model.pt" 2>/dev/null || echo "  缺失!"

echo ""
echo "============================================"
echo "下载完成!"
echo "下一步: 运行 demo_app.py 启动 Gradio Demo"
echo "============================================"
