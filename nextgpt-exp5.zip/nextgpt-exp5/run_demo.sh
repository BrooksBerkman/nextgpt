#!/bin/bash
# ============================================================
# NExT-GPT Gradio Demo 启动脚本
# 使用：bash run_demo.sh
# ============================================================

set -e

# 激活 conda 环境
conda activate nextgpt

# 项目根目录
PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
CODE_DIR="$PROJECT_ROOT/code"

cd "$CODE_DIR"

echo "============================================"
echo "启动 NExT-GPT Gradio Demo"
echo "============================================"
echo "代码目录: $CODE_DIR"
echo "Checkpoint 目录: $PROJECT_ROOT/ckpt"
echo ""

# 启动 Gradio Demo
python demo_app.py \
    --nextgpt_ckpt_path ../ckpt/delta_ckpt/nextgpt/7b_tiva_v0 \
    --mode train
