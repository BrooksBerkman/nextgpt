#!/bin/bash
# ============================================================
# NExT-GPT 代码修复补丁
# 功能：修复 demo_app.py 缺少 --mode 参数、data 模块缺失等问题
# 使用：bash fix_code.sh
# ============================================================

set -e

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
CODE_DIR="$PROJECT_ROOT/code"

echo "============================================"
echo "NExT-GPT 代码修复补丁"
echo "============================================"
echo ""

# 1. 修复 data 模块符号链接
echo "[1/3] 修复 data 模块符号链接..."
if [ -L "$CODE_DIR/data" ]; then
    echo "data 符号链接已存在，跳过"
elif [ -d "$CODE_DIR/data" ]; then
    echo "data 目录已存在（非符号链接），跳过"
else
    ln -s "$CODE_DIR/dataset" "$CODE_DIR/data"
    echo "已创建符号链接: code/data -> code/dataset"
fi
echo ""

# 2. 修复 demo_app.py 缺少 --mode 参数
echo "[2/3] 修复 demo_app.py 缺少 --mode 参数..."
if grep -q "'--mode'" "$CODE_DIR/demo_app.py"; then
    echo "--mode 参数已存在，跳过"
else
    # 使用 sed 添加 --mode 参数
    sed -i "s/parser.add_argument('--nextgpt_ckpt_path'/parser.add_argument('--mode', type=str, default='train')\n    parser.add_argument('--nextgpt_ckpt_path'/" "$CODE_DIR/demo_app.py"
    echo "已添加 --mode 参数"
fi
echo ""

# 3. 修复显存问题：添加 CPU offload
echo "[3/3] 修复显存问题（添加 CPU offload）..."
if grep -q "enable_sequential_cpu_offload" "$CODE_DIR/model/anyToImageVideoAudio.py"; then
    echo "CPU offload 已配置，跳过"
else
    echo "请手动修改 model/anyToImageVideoAudio.py 文件："
    echo "  将 StableDiffusionPipeline.from_pretrained().to('cuda')"
    echo "  改为使用 enable_sequential_cpu_offload() 方法以节省显存"
    echo "  参考: https://huggingface.co/docs/diffusers/v0.17.0/en/optimization/fp16#older-diffusers-versions-≤0170"
fi
echo ""

echo "============================================"
echo "代码修复完成!"
echo "============================================"
