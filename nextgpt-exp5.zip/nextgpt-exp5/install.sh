#!/bin/bash
# ============================================================
# NExT-GPT 环境安装脚本
# 功能：创建 conda 环境并安装所有依赖
# 使用：bash install.sh
# ============================================================

set -e

echo "============================================"
echo "NExT-GPT 环境安装脚本"
echo "============================================"

# 1. 创建 conda 环境
echo "[1/4] 创建 conda 环境 (Python 3.8)..."
conda create -n nextgpt python=3.8 -y
conda activate nextgpt

# 2. 安装 PyTorch
echo "[2/4] 安装 PyTorch 1.13.1 + CUDA 11.6..."
pip install torch==1.13.1 torchvision==0.14.1 torchaudio==0.13.1 \
    --index-url https://download.pytorch.org/whl/cu116

# 3. 安装项目依赖
echo "[3/4] 安装 NExT-GPT 依赖..."
pip install accelerate==0.19.0 datasets==2.12.0 deepspeed==0.9.3 \
    diffusers==0.17.0 einops==0.6.1 gradio==3.44.0 peft==0.3.0 \
    transformers==4.29.2 scipy>=1.10.0 sentencepiece

# 4. 验证安装
echo "[4/4] 验证安装..."
python -c "import torch; print(f'PyTorch: {torch.__version__}'); print(f'CUDA available: {torch.cuda.is_available()}')"
python -c "import transformers; print(f'transformers: {transformers.__version__}')"
python -c "import diffusers; print(f'diffusers: {diffusers.__version__}')"
python -c "import sentencepiece; print('sentencepiece: OK')"

echo ""
echo "============================================"
echo "安装完成!"
echo "下一步: 运行 download_checkpoints.sh 下载模型权重"
echo "激活环境: conda activate nextgpt"
echo "============================================"
